import time
import unittest
from HTMLTestRunner import HTMLTestRunner


class UnittestPerform:

        # 实例化一个suite；加载套件到suite中：loadTestsFromName('用例的全路径')
        suite = unittest.TestSuite()
        suite.addTests(unittest.TestLoader().loadTestsFromName('Shared_Parking.test_case.test_login_api.TestLoginAPI'))

        now = time.strftime("%Y-%m-%d_%H%M%S")                  # 生成report的时间
        file_name = "../report/" + now + "report.html"
        fp = open(file_name, "w")                               # 往html里写的是文本，用w写即可（图片要用wb二进制）
        runner = HTMLTestRunner(stream=fp, verbosity=2, title="37期自动化测试报告")
        runner.run(suite)
        fp.close()



if __name__ == '__main__':
    testperform =UnittestPerform()

