
from Shared_Parking.tools.lib_util import UiUtil


class Login:

    def __init__(self,driver):

        self.driver = driver

    def do_login(self):
        username = UiUtil.find_element('login','username')
        password = UiUtil.find_element('login', 'password')
        verifycode = UiUtil.find_element('login', 'verifycode')
        login_button = UiUtil.find_element('login','login_button')

        UiUtil.click(username)
        UiUtil.input(username,'物业0')
        UiUtil.click(password)
        UiUtil.input(password, '123')
        UiUtil.click(verifycode)
        UiUtil.input(verifycode, '0000')
        UiUtil.click(login_button)

if __name__ == '__main__':
    driver = UiUtil.get_driver()
    Login(driver).do_login()



