import pyautogui
from Shared_Parking.tools.lib_util import UiUtil
from Shared_Parking.action.do_login import Login


class Property:

    def __init__(self,driver):

        self.driver = driver

    def click_property(self):                           # 登录到主页后，点击物业方信息
        property = UiUtil.find_element('main_page','property')
        UiUtil.click(property)

    def preclick_query_option(self):                    # 在选项框悬停鼠标，以供下方进行选择
        self.click_property()
        UiUtil.switch_iframe('property','input_property_iframe')    # 切换至查询条件下拉框的iframe
        query_button = UiUtil.find_element('property', 'query_option')
        UiUtil.pre_click(query_button)                              # 鼠标悬停

    def choice_query_option(self,choice_option):        # 选择查询的条件
        self.preclick_query_option()
        name = UiUtil.find_element('property','name')
        phone = UiUtil.find_element('property','phone')
        state = UiUtil.find_element('property','state')
        if choice_option == name:
            UiUtil.click(name)
        elif choice_option == phone:
            pyautogui.click(x=697,y=450,button='left')
        elif choice_option == state:
            pyautogui.click(x=705,y=498,button='left')

    def click_input_property(self,choice_option,property_img):      # 点击 查询输入框
        self.choice_query_option(choice_option)
        UiUtil.switch_iframe('property','input_property_iframe')           # 元素嵌套在iframe下，必须先切换
        property_input = UiUtil.find_element('property', 'input_property') # 定位查询框
        UiUtil.click(property_input)
        UiUtil.input(property_input,property_img)                          # 输入会员的相关信息


    def click_query_button(self):                           # 点击 查询按钮
        query_button = UiUtil.find_element('property','query_button')
        UiUtil.click(query_button)

    def do_select_by_name(self,property_img):
        self.click_input_property("name",property_img)
        self.click_query_button()

    def do_select_by_phone(self,property_img):
        self.click_input_property("phone",property_img)
        self.click_query_button()

    def do_select_by_state(self,property_img):
        self.click_input_property("state",property_img)
        self.click_query_button()




if __name__ == '__main__':
    driver = UiUtil.get_driver()
    Login(driver).do_login()
    # Property(driver).do_select_by_name('物业304')
    # Property(driver).do_select_by_phone('13705368361')
    Property(driver).do_select_by_state('注销')
