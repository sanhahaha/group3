import unittest
from Shared_Parking.tools.util import FileUtil
from Shared_Parking.action import do_property
from Shared_Parking.tools import lib_util



class TestPropertyUI(unittest.TestCase):


    def test_property(self):
        test_info = do_property.Property.click_query_button('sun')
        lib_util.Assert(,test_info)




if __name__ == '__main__':
    unittest.main(verbosity=2)

